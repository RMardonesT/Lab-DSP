filtrada = out.p6_1_notch440;

audiowrite("p6_1_notch440.wav", filtrada, 16000  );